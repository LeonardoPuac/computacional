﻿namespace T1_JLPM1277023;

internal class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa");
        Console.WriteLine("Ingrese su nombre");
        string Nombre = Console.ReadLine();
        Console.WriteLine("Ingrese su Edad");
        string Edad = Console.ReadLine();
        Console.WriteLine("Ingrese su Carrera");
        string Carrera = Console.ReadLine();
        Console.WriteLine("Ingrese su Carne");
        string Carne = Console.ReadLine();
        Console.Write("Hola Mundo");
        Console.Write(" soy " + Nombre + " Tengo " + Edad + " años y estudio la carrera de " + Carrera + " Mi numero de carne es " + Carne);
        Console.ReadKey();
    }
}

